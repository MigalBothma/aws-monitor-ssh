import json
import json
import time
import os
import boto3

from actions import getInventoryToMonitor, invokeLinuxCommand, invokeWindowsCommand, getWindowsStatuses, sendAlert, filterByAWSTag
sleep_seconds = 10

# Get Environmental Variables
MONITOR_TAG = os.getenv('monitor_tag', default=None)
LINUX_CMD_TO_RUN = os.getenv('linux_cmd_to_run', default=None)
WINDOWS_CMD_TO_RUN = os.getenv('windows_cmd_to_run', default=None)
DEBUG = (os.getenv('debug', 'False') == 'True')
SQS_NOTIFICATION_URL = os.getenv('sqs_queue_url', default=None)

# Dry Run Testing
INJECT_FAILURE = (os.getenv('inject_failure', 'False') == 'True')
INJECT_FAILURE_PLATFORM = os.getenv('inject_failure_target_platform', 'Linux')
INJECT_FAILURE_IID = os.getenv('inject_failure_target_instance_id', '')

def lambda_handler(event, context):
    # Create SSM Client
    ssm_client = boto3.client('ssm')
    sqs_client = boto3.client('sqs')
    ec2_client = boto3.client('ec2')
    
    print(ssm_client, sqs_client)
    
    # Get Inventory to Monitor 
    linux_inventory, windows_inventory = getInventoryToMonitor(ssm_client=ssm_client, monitor_tag=MONITOR_TAG)
    linux_instanceIDs = [ x['Id'] for x in linux_inventory ]
    windows_instanceIDs = [ x['Id'] for x in windows_inventory ]
    hostnames_dict = {}
    
    # Filter out non tagged and show at the end as untagged!
    windows_instanceIDs, linux_instanceIDs, untagged, installSSM = filterByAWSTag(ec2_client, MONITOR_TAG, windows_instanceIDs, linux_instanceIDs)
    
    print(f'------------------')
    print(f'Found linux instances :')
    for instance in linux_inventory:
        data = instance['Data']['AWS:InstanceInformation']['Content'][0]
        hostnames_dict[instance["Id"]] = data["ComputerName"]
        print(f'{instance["Id"]} : {data["PlatformType"]} : {data["PlatformName"]} : {data["PlatformVersion"]} : {data["ComputerName"]}')
        if DEBUG:
            print(json.dumps(data, indent=4))
    print(f'------------------')
    print(f'Found windows instances :')
    for instance in windows_inventory:
        data = instance['Data']['AWS:InstanceInformation']['Content'][0]
        hostnames_dict[instance["Id"]] = data["ComputerName"]
        print(f'{instance["Id"]} : {data["PlatformType"]} : {data["PlatformName"]} : {data["PlatformVersion"]} : {data["ComputerName"]}')
        if DEBUG:
            print(json.dumps(data, indent=4))
    print(f'------------------')
    
    if DEBUG:
        print('-------------------')
        print('InstanceID : Hostnames Dictionary')
        print(json.dumps(hostnames_dict, indent=4))
        print('-------------------')
    
    print(f'------------------')
    print('Send Commands')
    # Run ssm sendCommand against the monitor tag hosts
    print(f'Linux -> running command : {LINUX_CMD_TO_RUN} on instances with tag : {MONITOR_TAG}')
    print(f'-')
    linux_resp = invokeLinuxCommand(ssm_client, linux_instanceIDs, LINUX_CMD_TO_RUN, MONITOR_TAG)
    linux_command_id = linux_resp['Command']['CommandId']
    print(f'Linux -> generated command id : {linux_command_id} targeting {len(linux_instanceIDs)} instances.')
    print(f'-')
    print(f'Windows -> running command : {WINDOWS_CMD_TO_RUN} on instances with tag : {MONITOR_TAG}')
    print(f'-')
    resp = invokeWindowsCommand(ssm_client, windows_instanceIDs, WINDOWS_CMD_TO_RUN, MONITOR_TAG)
    windows_command_id = resp['Command']['CommandId']
    print(f'Windows -> generated command id : {windows_command_id} targeting {len(windows_instanceIDs)} instances.')
    print(f'------------------')
    
    print(f'Waiting {sleep_seconds}s ...')
    time.sleep(sleep_seconds)
    
    output = {}
    errors = {}
    statusObj = {'Linux': {},'Windows': {}}
    
    print(f'------------------')
    print(f'Handle Command Outputs')
    print(f'------------------')
    print('Get Linux Responses')
    for instanceid in linux_instanceIDs:
        try:
            output[instanceid] = ssm_client.get_command_invocation(
                InstanceId=instanceid,
                CommandId=linux_command_id
            )
            if DEBUG:
                print(f'------------------')
                print(f'{instanceid} - {json.dumps(output[instanceid], indent=4)}')
                print(f'------------------')
            
            if instanceid not in statusObj['Linux']:
                statusObj['Linux'][instanceid] = {}
            
            if "health" not in statusObj['Linux'][instanceid]:
                statusObj['Linux'][instanceid]['Hostname'] = ""
                statusObj['Linux'][instanceid]['Health'] = "Warning"
                statusObj['Linux'][instanceid]['Status'] = "Error"
                statusObj['Linux'][instanceid]['Services'] = []
            
            if str(output[instanceid]["StandardOutputContent"]).strip() == "":
                output[instanceid]["StandardOutputContent"] = output[instanceid]["StandardErrorContent"] 
                
            if output[instanceid]["Status"] != "":
                statusObj['Linux'][instanceid]['Status'] = output[instanceid]["Status"]
                
            if instanceid in hostnames_dict:
                statusObj['Linux'][instanceid]['Hostname'] = hostnames_dict[instanceid]
                
            if "OpenSSH" in output[instanceid]["StandardErrorContent"]:
                statusObj['Linux'][instanceid]['Health'] = "Good"
                
            statusObj['Linux'][instanceid]['Services'] = [
                {
                    "Command": LINUX_CMD_TO_RUN,
                    "Service": "SSH",
                    "Response": output[instanceid]["StandardErrorContent"],
                    "Health": statusObj['Linux'][instanceid]['Health']
                }
            ]
        except Exception as e:
            if instanceid not in errors:
                errors[instanceid] = []
            if instanceid not in statusObj['Linux']:
                statusObj['Linux'][instanceid] = {}
            errors[instanceid].append(f'Error -> {repr(e)}')
            statusObj['Linux'][instanceid]['Health'] = "Bad"
            statusObj['Linux'][instanceid]['Status'] = "Error"
            print(f'Error on {instanceid} : {repr(e)}')
    
    print('Get Windows Responses')
    for instanceid in windows_instanceIDs:
        try:
            output[instanceid] = ssm_client.get_command_invocation(
                InstanceId=instanceid,
                CommandId=windows_command_id
            )

            if DEBUG:
                print(f'------------------')
                print(f'{instanceid} - {json.dumps(output[instanceid], indent=4)}')
                print(f'------------------')
            
            if instanceid not in statusObj['Windows']:
                statusObj['Windows'][instanceid] = {}
            
            if "health" not in statusObj['Windows'][instanceid]:
                statusObj['Windows'][instanceid]['Hostname'] = ""
                statusObj['Windows'][instanceid]['Health'] = "Warning"
                statusObj['Windows'][instanceid]['Status'] = "Error"
                statusObj['Windows'][instanceid]['Services'] = []
            
            if str(output[instanceid]["StandardOutputContent"]).strip() == "":
                output[instanceid]["StandardOutputContent"] = output[instanceid]["StandardErrorContent"] 
                
            statusObj['Windows'][instanceid]['Status'] = output[instanceid]["Status"]    
            
            if instanceid in hostnames_dict:
                statusObj['Windows'][instanceid]['Hostname'] = hostnames_dict[instanceid]

            if output[instanceid]["StandardOutputContent"] != "":
                serviceStatuses = getWindowsStatuses(output[instanceid]["StandardOutputContent"])
                _health = 'Warning'
                
                for service in serviceStatuses:
                    if serviceStatuses[service] == "Running":
                        _health = "Good"
                    statusObj['Windows'][instanceid]['Services'].append({
                        "Command": WINDOWS_CMD_TO_RUN,
                        "Service": service,
                        "Response": serviceStatuses[service],
                        "Health": _health
                    })
                    statusObj['Windows'][instanceid]['Health'] = _health
                
        except Exception as e:
            if instanceid not in errors:
                errors[instanceid] = []
            if instanceid not in statusObj['Windows']:
                statusObj['Windows'][instanceid] = {}
            errors[instanceid].append(f'Error -> {repr(e)}')
            statusObj['Windows'][instanceid]['Health'] = "Bad"
            statusObj['Windows'][instanceid]['Status'] = "Error"
            print(f'Error on {instanceid} : {repr(e)}')
    print(f'------------------')
    
    print(f'##################')
    print('Process And Send Alerts')
    print(f'##################')
    
    print(f'Inject Failure : {INJECT_FAILURE}')
    if INJECT_FAILURE:
        print(f'Inject Failure on : {INJECT_FAILURE_PLATFORM} : {INJECT_FAILURE_IID}')
        statusObj[INJECT_FAILURE_PLATFORM][INJECT_FAILURE_IID]['Health'] = "Warning"
        statusObj[INJECT_FAILURE_PLATFORM][INJECT_FAILURE_IID]['Status'] = "Error"
    
    for _platform in statusObj:
        for _instance in statusObj[_platform]:
            print(f'------------------')
            print(f'Alerts - Processing {_instance} : {_platform}')
            print(f'Health : {statusObj[_platform][_instance]["Health"]}, Status : {statusObj[_platform][_instance]["Status"]}')
            _data = statusObj[_platform][_instance]

            for _service in _data['Services']:
                print(f'{_service["Health"]} : {_service["Service"]} : {_service["Response"]}')
            print(f'------------------')
            
            if statusObj[_platform][_instance]["Health"] != "Good":
                sendAlert(sqs_client, SQS_NOTIFICATION_URL, _platform, _instance, statusObj[_platform][_instance])
    
    statusObj["Untagged"] = untagged
    statusObj["Install_SSM"]= installSSM
        
    print(f'------------------')
    print(f'-----Finished-----')
    print(f'------------------')
    
    if len(errors) > 0:
        print(f'##################')
        print('ERRORS')
        print(json.dumps(errors, indent=4))
        print(f'##################')
    
    # print(json.dumps(statusObj, indent=4))
    print(f'-------------------')
    
    return {
        'statusCode': 200,
        'body': json.dumps(statusObj)
    }
