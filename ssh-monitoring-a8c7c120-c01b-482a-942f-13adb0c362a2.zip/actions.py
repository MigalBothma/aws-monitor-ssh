import json
import re

def getInventoryToMonitor(ssm_client, monitor_tag):
    linux_inventory = []
    windows_inventory = []
    
    paginator = ssm_client.get_paginator('get_inventory')
    for page in paginator.paginate(PaginationConfig={'MaxItems': 1000}):
        for entity in page['Entities']:
            if entity['Data'] != {}:
                if 'AWS:InstanceInformation' in entity['Data']:
                    if 'Content' in entity['Data']['AWS:InstanceInformation']:
                        if len(entity['Data']['AWS:InstanceInformation']['Content']) > 0:
                            # Instance Info
                            data = entity['Data']['AWS:InstanceInformation']['Content'][0]
                            
                            # Only active running instances
                            if data["InstanceStatus"] == "Active":
                                if data["PlatformType"] == "Windows":
                                    windows_inventory.append(entity)
                                if data["PlatformType"] == "Linux":
                                    linux_inventory.append(entity)
    return (linux_inventory, windows_inventory)
    
def invokeLinuxCommand(ssm_client, linux_instanceIDs, linux_cmd_to_run, monitor_tag):
    resp = ssm_client.send_command(
        InstanceIds=linux_instanceIDs,
        Targets=[{
            'Key' : f'tag:{monitor_tag}',
            'Values': [
                '1'
            ]
        }],
        DocumentName="AWS-RunShellScript",
        DocumentVersion="1",
        Parameters={
            'commands':[f'{linux_cmd_to_run}']
        },
        TimeoutSeconds=30,
        MaxConcurrency="50",
        MaxErrors='0'
    )
    return resp
    
def invokeWindowsCommand(ssm_client, windows_instanceIDs, windows_cmd_to_run, monitor_tag):
    resp = ssm_client.send_command(
        Targets=[{
            'Key' : f'tag:{monitor_tag}',
            'Values': [
                '1'
            ]
        }],
        DocumentName="AWS-RunPowerShellScript",
        DocumentVersion="1",
        Parameters={
            'commands':[f'{windows_cmd_to_run}']
        },
        TimeoutSeconds=30,
        MaxConcurrency="50",
        MaxErrors='0'
    )
    return resp
    
def getWindowsStatuses(res_string):
    resp = {}
    obj = re.search(
        r"(?P<UmRdpService>\w+)\s\sUmRdpService.*\s(?P<TermService>\w+)\s\sTermService",
        res_string,
        re.MULTILINE
    )
    
    if obj != None:
        _data = obj.groupdict()
        # print(f'_data: {_data}')
        for group in _data:
            resp[group] = _data[group]
            
    return resp
    
def sendAlert(sqs_client, sqs_notification_url, platform, instance, statusObj):
    print(f'# Sending alert : {platform} : {instance} with {statusObj["Health"]} Status.')
    
    resp = sqs_client.send_message(
        QueueUrl=str(sqs_notification_url),
        MessageBody=str(json.dumps(statusObj))
    )
    
    print(f'# Sending alert response : {resp}')
    return resp
    
def filterByAWSTag(ec2_client, monitor_tag, windows_instanceIDs, linux_instanceIDs):
    _windows_instanceIDs = []
    _linux_instanceIDs = []
    _untagged = {
        'Windows': [],
        'Linux': []
    }
    _installSSM = []
    
    status = ec2_client.describe_instances(
        Filters=[
            {
                'Name': f'tag:{monitor_tag}',
                'Values': [
                    '1'
                ]
            }
        ]
    )
    
    print(status)
    
    for reservation in status["Reservations"]:
        for instance in reservation["Instances"]:
            # Did we find a windows instance with a tag and also in inventory
            if instance['InstanceId'] in windows_instanceIDs:
                _windows_instanceIDs.append(instance['InstanceId'])
            # Did we find a linux instance with a tag and also in inventory
            if instance['InstanceId'] in linux_instanceIDs:
                _linux_instanceIDs.append(instance['InstanceId'])
            
            # If not in inventory, but tagged, no SSM installed
            if instance["InstanceId"] not in windows_instanceIDs and instance["InstanceId"] not in linux_instanceIDs:
                _installSSM.append(instance["InstanceId"])

    for instance in windows_instanceIDs:
        if instance not in _windows_instanceIDs:
            _untagged['Windows'].append(instance)
            
    for instance in linux_instanceIDs:
        if instance not in _linux_instanceIDs:
            _untagged['Linux'].append(instance)

    return (_windows_instanceIDs, _linux_instanceIDs, _untagged, _installSSM)